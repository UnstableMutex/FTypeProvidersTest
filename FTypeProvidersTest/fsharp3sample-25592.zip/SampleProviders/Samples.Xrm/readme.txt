// Copyright (c) Microsoft Corporation 2005-2013.
// This sample code is provided "as is" without warranty of any kind. 
// We disclaim all warranties, either express or implied, including the 
// warranties of merchantability and fitness for a particular purpose.

In order to use this type provider you will ned Microsoft Identity Model installed on the client machine.

This has been built against the Microsoft Dynamics CRM 2011 SDK Version 5.0.12