﻿namespace FSharpLib

type T = Samples.ShareInfo.TPTest.TPTestType

