﻿
Please install Office OpenXML SDK from http://msdn.microsoft.com/en-us/library/office/bb448854.aspx