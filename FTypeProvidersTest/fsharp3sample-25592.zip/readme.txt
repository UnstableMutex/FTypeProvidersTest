FSharp Sample v2.0

Thank you downloading the FSharp sample package.

Database

1. why we need a database?
   Type Provider needs a database to perform query. You can download SQL Server 2008 Express for free. This database has to be on the local host and SA password is FSharpSample1234.
2. Any free database system to download?
   YES. You can download SQL Server 2008 Express for free. 
3. what is the credential for the database
   This database has to be on the local host and SA password is FSharpSample1234.
4. how to setup the database
   If you have perfer to use the .sql script directly, it is under the SampleProject folder. Its name is CreateFSharpSampleDatabase.sql. Another choice is to run setup.exe, please make sure the CreateFSharpSampleDatabase.sql and setup.exe are at the same folder.
5. What happen if I do want to setup a database?
   If there is no database, the SQL type provider won't be compiled and you will get warning message(s). 

Enjoy the journey to F# programming.